# 時を彩る 塗り絵ガイド｜GitHub Pages公開セット

このフォルダをそのままGitHubへアップロードすると、スマホ向けガイドとして公開できます。専門用語の「タグ」を書く必要はありません。

## いちばん簡単な公開手順

1. GitHubへログインし、右上の `＋` → `New repository` を押す
2. Repository name に `antique-coloring-guide` と入力
3. `Public` を選び、`Create repository` を押す
4. `uploading an existing file` を押す
5. **このフォルダの中身すべて**を、GitHubの画面へドラッグ＆ドロップ
6. 下にある `Commit changes` を押す
7. 上部の `Settings` → 左側の `Pages` を開く
8. `Build and deployment` の Source を `Deploy from a branch` にする
9. Branchを `main`、フォルダを `/(root)` にして `Save`
10. 1～5分後、同じ画面に公開URLが表示される

公開URLは通常、次の形です。

`https://あなたのGitHub名.github.io/antique-coloring-guide/`

## 画像を入れ替える場所

`assets/images` フォルダ内の画像を、同じ名前で置き換えます。

- 1番：`01.webp`
- 2番：`02.webp`
- 20番：`20.webp`
- おまけ1：`bonus-1.webp`
- おまけ2：`bonus-2.webp`
- 表紙：`cover.webp`
- 裏表紙：`back-cover.webp`

画像はPNGまたはJPGが使えます。ただしJPGに変える場合は `content.js` の画像名も変更してください。

## 作品名・説明文を変える場所

`content.js` だけを編集します。「初心者が変更する場所」という印の下に、作品名と一言アドバイスがあります。

## おまけページを表示・非表示にする方法

現在は、おまけ1・2が表示される設定です。非表示にしたい場合だけ、`content.js` の最後にある該当画像の `enabled: true` を `enabled: false` に変えます。

## 色見本について

このガイドは、一般的な12色を基本にしています。色鉛筆の色名と発色はメーカーによって異なるため、画面の色は目安として、お手持ちの近い色で調整してください。

## 大切な注意

- `index.html` はトップページなので、名前を変えないでください。
- フォルダごとではなく、**フォルダの中身**をGitHubへ入れます。
- リポジトリを削除・非公開化すると、公開ページも見られなくなります。
- 本にQRコードを印刷する前に、スマホで公開URLを開いて確認してください。
