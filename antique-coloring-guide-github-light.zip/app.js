(() => {
  const works = [...GUIDE.works].sort((a, b) => a.number - b.number);
  const bonus = GUIDE.bonuses.filter(item => item.enabled);
  const pages = [
    { type: "cover" },
    { type: "palette" },
    { type: "mixing" },
    { type: "lesson" },
    ...works.map(work => ({ type: "work", work })),
    ...(bonus.length ? [{ type: "bonus" }, { type: "message" }] : []),
    { type: "back" }
  ];
  let current = 0;

  const baseColors = [
    ["あお", "#55739c"], ["むらさき", "#8c7098"], ["あか", "#b95159"],
    ["ももいろ", "#dc8e9e"], ["だいだいいろ", "#d98951"], ["きいろ", "#e2bf5f"],
    ["きみどり", "#a6b873"], ["みどり", "#66846a"], ["みずいろ", "#86aec1"],
    ["うすだいだい", "#e2b390"], ["くろ", "#4c4849"], ["ちゃいろ", "#876552"]
  ];
  const recipes = [
    ["オールドローズ", "ももいろ", "あか", "ちゃいろ", "茶色は影だけにごく薄く"],
    ["アンティークブルー", "みずいろ", "あお", "ちゃいろ", "青の上に茶色を重ねすぎない"],
    ["くすみラベンダー", "ももいろ", "むらさき", "あお", "紫は中央と影を中心に"],
    ["セージグリーン", "きみどり", "みどり", "ちゃいろ", "葉脈と根元だけを濃く"],
    ["アイボリー", "紙の白", "きいろ", "うすだいだい", "白を多く残して温かい影だけ"],
    ["淡い金茶", "きいろ", "だいだいいろ", "ちゃいろ", "光る中央を白く残す"]
  ];

  const app = document.querySelector("#app");
  app.innerHTML = `
    <section class="phone" aria-label="${GUIDE.bookTitle}">
      <div class="page" id="page"></div>
      <nav class="controls" aria-label="ページ操作">
        <button id="prev" type="button" aria-label="前のページ">‹</button>
        <button id="toc" type="button" aria-label="目次を開く"><span id="counter"></span></button>
        <button id="next" type="button" aria-label="次のページ">›</button>
      </nav>
      <dialog id="drawer">
        <div class="drawer-head"><strong>作品一覧</strong><button id="close" aria-label="閉じる">×</button></div>
        <ol id="list"></ol>
      </dialog>
    </section>`;

  const page = document.querySelector("#page");
  const counter = document.querySelector("#counter");
  const drawer = document.querySelector("#drawer");

  function render() {
    const item = pages[current];
    page.className = `page page-${item.type}`;
    if (item.type === "cover") {
      page.innerHTML = `<img class="book-cover" src="${GUIDE.cover}" alt="${GUIDE.bookTitle} 表紙"><button class="start cover-start" data-next>ガイドをひらく</button>`;
    } else if (item.type === "palette") {
      page.innerHTML = `<header><span>BASE PALETTE</span><h2>12色から始める<br>アンティークカラー</h2></header><p class="lead">特別な色を買い足さなくても大丈夫。一般的な12色を淡く重ね、深みとくすみを作ります。</p><div class="swatches">${baseColors.map(([name, color]) => `<div><i style="--swatch:${color}"></i><span>${name}</span></div>`).join("")}</div><p class="note">画面の色は目安です。色名・発色はメーカーや端末によって異なるため、お手持ちの近い基本色で調整してください。</p>`;
    } else if (item.type === "mixing") {
      page.innerHTML = `<header><span>LAYERING RECIPE</span><h2>色の作り方・重ね方</h2></header><p class="lead">左から順に、弱い筆圧で重ねます。後の色ほど塗る範囲を狭くすると、自然な濃淡になります。</p><div class="recipes">${recipes.map(r => `<article><h3>${r[0]}</h3><div><b>${r[1]}</b><em>＋</em><b>${r[2]}</b><em>＋</em><b>${r[3]}</b></div><p>${r[4]}</p></article>`).join("")}</div><p class="note">「紙の白」は色ではなく、塗らずに残す光です。黒は輪郭や最も暗い部分だけに使うと、透明感を保てます。</p>`;
    } else if (item.type === "lesson") {
      page.innerHTML = `<header><span>BASIC TECHNIQUE</span><h2>基本の塗り方、4つのコツ</h2></header><div class="lesson"><article><b>1</b><h3>淡い色から</h3><p>最初は軽い筆圧で、紙の白さを残します。</p></article><article><b>2</b><h3>面は鉛筆を寝かせる</h3><p>広い下地は芯の側面で、むらを抑えて薄く塗ります。</p></article><article><b>3</b><h3>形の流れに沿う</h3><p>花びら、髪、布の流れに沿って鉛筆を動かします。</p></article><article><b>4</b><h3>影だけ少し濃く</h3><p>一度で濃くせず、塗る範囲を狭めながら重ねます。</p></article></div>`;
    } else if (item.type === "work") {
      const w = item.work;
      page.innerHTML = `<header><span>COLOR SAMPLE ${String(w.number).padStart(2, "0")}</span><h2>${w.title}</h2></header><figure><img src="${w.image}" alt="${w.title}のカラー見本"><figcaption><i></i><p>${w.tip}</p></figcaption></figure>`;
    } else if (item.type === "bonus") {
      page.innerHTML = `<header><span>SPECIAL BONUS</span><h2>同じ図案、二つの彩り</h2></header><div class="bonus-grid">${bonus.map(b => `<figure><img src="${b.image}" alt="${b.title}"><figcaption><small>${b.label}</small>${b.title}</figcaption></figure>`).join("")}</div>`;
    } else if (item.type === "message") {
      page.innerHTML = `<div class="end-mark">❦</div><p class="eyebrow">COLOR CHANGES THE STORY</p><h2>色が変われば、<br>物語も変わる</h2><p class="bonus-message final-message">${GUIDE.bonusMessage}</p>`;
    } else {
      page.innerHTML = `<img class="book-cover" src="${GUIDE.backCover}" alt="${GUIDE.bookTitle} 裏表紙"><button class="start cover-start" data-home>最初に戻る</button>`;
    }
    counter.textContent = `${current + 1} / ${pages.length}`;
    document.querySelector("#prev").disabled = current === 0;
    document.querySelector("#next").disabled = current === pages.length - 1;
    page.scrollTop = 0;
  }

  function move(amount) { current = Math.max(0, Math.min(pages.length - 1, current + amount)); render(); }
  document.querySelector("#prev").addEventListener("click", () => move(-1));
  document.querySelector("#next").addEventListener("click", () => move(1));
  page.addEventListener("click", e => { if (e.target.closest("[data-next]")) move(1); if (e.target.closest("[data-home]")) { current = 0; render(); } });
  document.addEventListener("keydown", e => { if (e.key === "ArrowLeft") move(-1); if (e.key === "ArrowRight") move(1); });
  let startX = 0;
  page.addEventListener("touchstart", e => { startX = e.changedTouches[0].clientX; }, { passive: true });
  page.addEventListener("touchend", e => { const dx = e.changedTouches[0].clientX - startX; if (Math.abs(dx) > 55) move(dx < 0 ? 1 : -1); }, { passive: true });

  document.querySelector("#list").innerHTML = works.map((w, i) => `<li><button data-page="${i + 4}"><span>${String(w.number).padStart(2, "0")}</span>${w.title}</button></li>`).join("");
  document.querySelector("#toc").addEventListener("click", () => drawer.showModal());
  document.querySelector("#close").addEventListener("click", () => drawer.close());
  drawer.addEventListener("click", e => { const button = e.target.closest("[data-page]"); if (button) { current = Number(button.dataset.page); drawer.close(); render(); } });
  render();
})();
