/* =============================================================
   ★ 初心者が変更する場所は、このファイルだけです ★

   画像の入れ替え方：
   1. assets/images の中の 01.webp、02.webp…を同名で置き換える
   2. 下の title（作品名）と tip（塗り方の一言）を変更する
   3. 番号順は自動で並びます

   注意：カンマ「,」や引用符「\"」を消さないでください。
   ============================================================= */

const GUIDE = {
  bookTitle: "時を彩る 塗り絵ガイド",
  subtitle: "花とドレスのアンティーク物語",
  introduction: "色鉛筆の重なりから生まれる、やさしい物語。見本をめくりながら、あなたらしい色を見つけてください。",
  cover: "assets/images/cover.webp",
  backCover: "assets/images/back-cover.webp",

  works: [
    { number: 1,  title: "彩るアンティークの世界", image: "assets/images/01.webp", tip: "淡い色から少しずつ重ね、紺色を引き締め役に。" },
    { number: 2,  title: "ローズリボン", image: "assets/images/02.webp", tip: "ピンクを一色で塗らず、明るさの違う色を重ねます。" },
    { number: 3,  title: "あなたのそばに", image: "assets/images/03.webp", tip: "肌と衣装は力を抜き、髪の線に沿って色を重ねます。" },
    { number: 4,  title: "永遠の幸せ", image: "assets/images/04.webp", tip: "白を残す部分を決めると、透明感が生まれます。" },
    { number: 5,  title: "アンティークレース", image: "assets/images/05.webp", tip: "レースは真っ白を残し、影だけを薄く入れます。" },
    { number: 6,  title: "世界にふたりだけ", image: "assets/images/06.webp", tip: "花・服・葉の三つの色群に分けるとまとまります。" },
    { number: 7,  title: "アンティーク色の花飾りドレス", image: "assets/images/07.webp", tip: "クリーム色を下地にすると、古風な温かさが出ます。" },
    { number: 8,  title: "ドレスを纏う翼の少女", image: "assets/images/08.webp", tip: "ミントとピンクの面積差をつけて主役を決めます。" },
    { number: 9,  title: "アンティークローズとレースの花飾り", image: "assets/images/09.webp", tip: "花は中心を濃く、レースは紙の白を残して軽やかに。" },
    { number: 10, title: "子ども心の恋模様", image: "assets/images/10.webp", tip: "赤は薄い朱色から重ね、最後に濃い赤を足します。" },
    { number: 11, title: "時を操る花時計", image: "assets/images/11.webp", tip: "金属は黄色・だいだい色・茶色を薄く重ねます。" },
    { number: 12, title: "大人心の恋模様", image: "assets/images/12.webp", tip: "同系色でも、明暗を変えると奥行きが生まれます。" },
    { number: 13, title: "小鳥と優雅なティータイム", image: "assets/images/13.webp", tip: "背景は筆圧を弱くして、人物より淡く仕上げます。" },
    { number: 14, title: "エメラルドの装い", image: "assets/images/14.webp", tip: "緑を主役にし、リボンのピンクを小さなアクセントに。" },
    { number: 15, title: "時の番人とともに行く", image: "assets/images/15.webp", tip: "羽根は白を残し、付け根だけに淡い影を入れます。" },
    { number: 16, title: "時計と花が彩る永遠の魔法", image: "assets/images/16.webp", tip: "ピンクと紫を薄く重ね、黄色と茶色で金属の光を添えます。" },
    { number: 17, title: "琥珀の黄昏に咲く花", image: "assets/images/17.webp", tip: "水色と琥珀色を交互に置き、夕暮れの光を作ります。" },
    { number: 18, title: "夢見る優雅な舞踏会", image: "assets/images/18.webp", tip: "ドレスのひだは、谷を濃く山を明るく塗ります。" },
    { number: 19, title: "夜明け前の銀色の城", image: "assets/images/19.webp", tip: "空から城へ、淡い紫と青を響かせます。" },
    { number: 20, title: "色づく花の舞踏会", image: "assets/images/20.webp", tip: "紺・ピンク・紫を繰り返して画面をつなぎます。" }
  ],

  /* おまけ画像を追加したら enabled を true にしてください */
  bonuses: [
    { label: "おまけ 1", title: "心が弾む、明るいピンク", image: "assets/images/bonus-1.webp", enabled: true },
    { label: "おまけ 2", title: "時を重ねた、アンティークローズ", image: "assets/images/bonus-2.webp", enabled: true }
  ],

  bonusMessage: "同じ図案でも、選ぶ色や重ね方によって、作品の表情はこんなにも変わります。明るいピンクなら、心が弾む華やかな世界に。くすみカラーなら、時を重ねた優雅なアンティークの世界に。見本は正解ではありません。あなたが心惹かれる色を選んで、あなただけの物語に彩ってみてください。"
};
